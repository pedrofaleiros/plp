O programa estava levando muito tempo para
apresentar todos os primos entre 0 e 99999
(quase 1 minuto no meu computador).
Entao dei a opcao de apresentar todos os primos 
entre 0 e 9999(em vez de 99999), com uma thread 
para cada faixa de 1000 valores(em vez de 10000)

Para rodar no terminal:
python threads.py

E depois escolher uma opcao:
Aperte 2 para apresentar todos primos entre 0 e 99999
e qualquer caractere para apresentar todos os primos entre 0 e 9999